var jsonData = JSON.parse(responseBody);

    //Test and Response
if(responseCode.code == 200){
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["access token is Not Null"] = jsonData.accessToken !== null);
    (tests["userPublicId is Not Null"] = jsonData.userPublicId !== null);
    (tests["fullName is Not Null"] = jsonData.fullName !== null);
    (tests["phone is Not Null"] = jsonData.phone !== null);
    (tests["iat is Not Null"] = jsonData.iat !== null);    
    (tests["exp is Not Null"] = jsonData.exp !== null);
    
    //Set Environment
    postman.setEnvironmentVariable("accessToken", jsonData.accessToken);
    postman.setEnvironmentVariable("userPublicId", jsonData.userPublicId);
    postman.setEnvironmentVariable("iat", jsonData.iat);
    postman.setEnvironmentVariable("exp", jsonData.exp);
    // Set Next Request
    postman.setNextRequest("Initiate Verify Phone (Send OTP) - Login");
    
} else if (responseCode.code == 401){
    (tests["Status Code is 401"] = responseCode.code = 401);
    (tests["Status Code Name Unauthorized"] = responseCode.name.has("Unauthorized"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["Code is Not Null"] = jsonData.code !== null);
    (tests["Message is Not Null"] = jsonData.code !== null);
    
} else {
    postman.setNextRequest("Retrieve Access Token (Login)");
}