
    //Test and Response
if(responseCode.code == 200){
    var jsonData = JSON.parse(responseBody);
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["phoneVerificationId is not null"] = jsonData.phoneVerificationId !== null);
    
    // Set Environment
    postman.setEnvironmentVariable("phoneVerificationId", jsonData.phoneVerificationId);

    // Set Next Request
    postman.setNextRequest("Verify Password - User");
    
} else if (responseCode.code == 404){
    var jsonData = JSON.parse(responseBody);
    (tests["Status Code is 404"] = responseCode.code = 404);
    (tests["Status Code Name Not Found"] = responseCode.name.has("Not Found"));
    (tests["Body is Not Null"] = responseBody !==null);
    (tests["Code Has Name"] = jsonData.code.has("NotFoundError"));
    (tests["Message Has Name"] = jsonData.message.has("kode otp tidak ditemukan / sudah kadaluarsa"));
    
} else if (responseCode.code == 422){
    var jsonData = JSON.parse(responseBody);
    (tests["Status Code is 422"] = responseCode.code = 422);
    (tests["Status Code Name Unprocessable Entity"] = responseCode.name.has("Unprocessable Entity"));
    (tests["Body is Not Null"] = responseBody !==null);
    if(jsonData.code.has("TokenInvalidError") && jsonData.message.has("otp tidak benar / sudah kadaluarsa") === tests["Code Invalid Error False OTP"]);
    else(jsonData.code.has("ValidationError") && jsonData.message.has("Validasi gagal") === tests["Code Validation Error Empty OTP"]);
        var fields = jsonData[fields];
        tests["Valid Field Has Status"] = jsonData.valid ===false;
        (tests["Message Field Has Name"] = jsonData.message.has("Tidak boleh kosong"));
        (tests["Field Field Has Name"] = jsonData.field === ("otp"));
        
} else if (responseCode.code == 429){
    (tests["Status Code is 429"] = responseCode.code = 429);
    (tests["Status Code Name Too Many Requests"] = responseCode.name.has("Too Many Requests"));
    
} else {
    postman.setNextRequest("Initiate Verify Phone (Send OTP) - User");
}