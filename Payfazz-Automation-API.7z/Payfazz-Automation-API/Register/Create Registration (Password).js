var jsonData = JSON.parse(responseBody);

    //Test and Response
if(responseCode.code == 200){
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["registrationId is not null"] = jsonData.registrationId !== null);
    (tests["phone is not null"] = jsonData.phone !== null);
    (tests["fullName is not null"] = jsonData.fullName !== null);
    
    // Set Environment
    postman.setEnvironmentVariable("registrationId", jsonData.registrationId);
    postman.setEnvironmentVariable("ResultPhone", jsonData.phone);
    postman.setEnvironmentVariable("ResultName", jsonData.fullName);

    // Set Next Request
    postman.setNextRequest("Create Registration (Referral Code)");
} else if(responseCode.code == 404){
    (tests["Status Code is 404"] = responseCode.code = 404);
    (tests["Status Code Name Not Found"] = responseCode.name.has("Not Found"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["Code is Not Null"] = jsonData.code !== null);
    (tests["Message is Not Null"] = jsonData.code !== null);

} else {
    postman.setNextRequest("Initiate Verify Phone (Send OTP)");
}