var jsonData = JSON.parse(responseBody);

    //Test and Response
if(responseCode.code == 200){
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["registrationId is not null"] = jsonData.registrationId !== null);
    (tests["phone is not null"] = jsonData.phone !== null);
    (tests["fullName is not null"] = jsonData.fullName !== null);
    if (jsonData.fullName !== null == tests["fullName condition"]);
    else(jsonData.fullName === null == tests["fullName condition"]);
    
    // Set Environment
    postman.setEnvironmentVariable("registrationId", jsonData.registrationId);
    postman.setEnvironmentVariable("ResultPhone", jsonData.phone);
    postman.setEnvironmentVariable("ResultName", jsonData.fullName);
    postman.setEnvironmentVariable("ResultReferral", jsonData.referralCode);


    // Set Next Request
    postman.setNextRequest("Create User");

} else if (responseCode.code == 422){
    (tests["Status Code is 422"] = responseCode.code = 422);
    (tests["Status Code Name Unprocessable Entity"] = responseCode.name.has("Unprocessable Entity"));
    (tests["Body is Not Null"] = responseBody !==null);
    (tests["Code Has Name"] = jsonData.code.has("ValidationError"));
    (tests["Message Has Name"] = jsonData.message.has("Validasi gagal"));
    var fields = jsonData[fields];
    tests["Valid Field Has Status"] = jsonData.valid ===false;
    (tests["Message Field Has Name"] = jsonData.message.has("Kode referal tidak terdaftar"));
    (tests["Field Field Has Name"] = jsonData.field === ("referralCode"));
} else {
    postman.setNextRequest("Initiate Verify Phone (Send OTP)");
}