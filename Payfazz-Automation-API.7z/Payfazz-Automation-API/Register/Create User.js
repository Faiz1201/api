var jsonData = JSON.parse(responseBody);

    //Test and Response
if(responseCode.code == 200){
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["fullName is not null"] = jsonData.fullName !== null);
 //   (tests["fullName Has Name"] = jsonData.fullName.has("{{FullName}}"));
    (tests["phone is Not Null"] = jsonData.phone !== null);
//    (tests["phone Has Name"] = jsonData.phone.has("{{PhoneNumber}}"));
    (tests["qr is Not Null"] = jsonData.qr !== null);
    
    //Set Environment
    postman.setEnvironmentVariable("QR", jsonData.qr);
    // Set Next Request
    postman.setNextRequest("Retrieve Access Token (Login)");
    
} else if (responseCode.code == 404){
    (tests["Status Code is 404"] = responseCode.code = 404);
    (tests["Status Code Name Not Found"] = responseCode.name.has("Not Found"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["Code is Not Null"] = jsonData.code !==null);
    (tests["Code Has Name"] = jsonData.code.has("NotFoundError"));
    (tests["Message is Not Null"] = jsonData.message !==null);
    (tests["Message Has Name"] = jsonData.message.has("registration is not found"));
} else {
    postman.setNextRequest("Initiate Verify Phone (Send OTP)");
}