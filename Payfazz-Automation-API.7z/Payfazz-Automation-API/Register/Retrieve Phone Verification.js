
    // Test and Response
    // Valid Input Data 
if(responseCode.code == 200){
    var jsonData = JSON.parse(responseBody);
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["phoneVerificationId is not null"] = jsonData.phoneVerificationId !== null);
    (tests["phone is Not Null"] = jsonData.phone !== null);
    (tests["otp is Not Null"] = jsonData.otp !== null);
    
    // Set Environment
    postman.setEnvironmentVariable("otp", jsonData.otp);

    postman.setNextRequest("Verify Phone");
    
} else if(responseCode.code == 404) {
    (tests["Status Code is 404"] = responseCode.code = 404);
    (tests["Status Code Name Not Found"] = responseCode.name.has("Not Found"));
    var jsonData = JSON.parse(responseBody);
    if (responseBody !== null === tests["Body is Not Null"]);
    else (null);

} else {
    postman.setNextRequest("Initiate Verify Phone (Send OTP)");
}