
    // Test and Response
    // Valid Input Data 
if(responseCode.code == 200){
    var jsonData = JSON.parse(responseBody);
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["phoneVerificationId is not null"] = jsonData.phoneVerificationId !== null);
    
    // Set Environment
    postman.setEnvironmentVariable("phoneVerificationId", jsonData.phoneVerificationId);
    postman.setEnvironmentVariable("PhoneNumber", request.data.phone);
    
    // Set Next Request
    postman.setNextRequest("Retrieve Phone Verification");
    
    // Invalid Input Data
} else if (responseCode.code == 422){
    var jsonData = JSON.parse(responseBody);
    (tests["Status Code is 422"] = responseCode.code = 422);
    (tests["Status Code Name Unprocessable Entity"] = responseCode.name.has("Unprocessable Entity"));
    (tests["Body is Not Null"] = responseBody !== null);
    if (request.data.phone === "" && jsonData.message[0].has("Tidak boleh kosong" == tests["False Phone Number"]));
    else (jsonData.message[0].has("No HP tidak valid") == tests["False Phone Number"]);
    
} else if(responseCode.code == 404){
    (tests["Status Code is 404"] = responseCode.code = 404);
    (tests["Status Code Name Not Found"] = responseCode.name.has("Not Found"));
    
} else if(responseCode.code == 429){
    (tests["Status Code is 429"] = responseCode.code = 429);
    (tests["Status Code Name Too Many Request"] = responseCode.name.has("Too Many Request"));
    
} else {
    postman.setNextRequest(null);
}