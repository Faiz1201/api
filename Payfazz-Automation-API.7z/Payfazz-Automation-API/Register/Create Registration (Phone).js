var jsonData = JSON.parse(responseBody);

    //Test and Response
if(responseCode.code == 200){
    (tests["Status Code is 200"] = responseCode.code = 200);
    (tests["Status Code Name OK"] = responseCode.name.has("OK"));
    (tests["Body is Not Null"] = responseBody !== null);
    (tests["registrationId is not null"] = jsonData.registrationId !== null);
    (tests["phone is not null"] = jsonData.phone !== null);
    
    // Set Environment
    postman.setEnvironmentVariable("registrationId", jsonData.registrationId);
    postman.setEnvironmentVariable("ResultPhone", jsonData.phone);

    // Set Environment
    postman.setEnvironmentVariable("registrationId", jsonData.registrationId);
    
    // Set Next Request
    postman.setNextRequest("Create Registration (Phone Verification ID)");
    
} else if (responseCode.code == 422){
    (tests["Status Code is 422"] = responseCode.code = 422);
    (tests["Status Code Name Unprocessable Entity"] = responseCode.name.has("Unprocessable Entity"));
    (tests["Body is Not Null"] = responseBody !==null);
    (tests["Code Has Name"] = jsonData.code.has("ValidationError"));
    (tests["Message Has Name"] = jsonData.message.has("Validasi gagal"));
    var fields = jsonData[fields];
    if (jsonData.message.has("No HP tidak valid") == tests["Message Field Has Name"]);
    else (jsonData.message.has("Tidak boleh kosong" == tests["Message Field Has Name"]));
   
} else {
    postman.setNextRequest("Initiate Verify Phone (Send OTP)");
}