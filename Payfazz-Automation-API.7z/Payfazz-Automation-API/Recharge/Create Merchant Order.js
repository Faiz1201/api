
    // Valid Response
    if(responseCode.code == 200){
        var jsonData = JSON.parse(responseBody);
        (tests["Status Code is 200"] = responseCode.code = 200);
        (tests["Status Code Name is OK"] = responseCode.name.has("OK"));
        (tests["Body is Not Null"] = responseBody !== null);
        (tests["Order Id is Not Null"] = jsonData.orderId !== null);
        (tests["Title is Not Null"] = jsonData.title !== null);
        (tests["Description is Not Null"] = jsonData.description !== null);
        (tests["Image is Not Null"] = jsonData.image !== null);
        (tests["UserID is Not Null"] = jsonData.userId !== null);
        (tests["SellPrice is Not Null"] = jsonData.sellPrice !== null);
        (tests["Status is Not Null"] = jsonData.status !== null);
        (tests["Main Type is Not Null"] = jsonData.mainType !== null);
        (tests["Product Type is Not Null"] = jsonData.productType !== null);
        (tests["Expired At is Not Null"] = jsonData.expiredAt !== null);
        (tests["Created At is Not Null"] = jsonData.createdAt !== null);
        (tests["MetaData is Not Null"] = jsonData.metadata !== null);
            // MetaData
            (tests["Note is Not Null"] = jsonData.note !== null);
            (tests["Merchant ID is Not Null"] = jsonData.merchantId !== null);
            (tests["Merchant Name is Not Null"] = jsonData.merchantName !== null);
            (tests["Merchant Phone is Not Null"] = jsonData.merchantPhone !== null);
        
        (tests["Order Items is Not Null"] = jsonData.orderItems !== null);
        var order = jsonData[orderItems];
            (tests["Item ID is Not Null"] = jsonData.itemId !== null);
            (tests["Order ID is Not Null"] = jsonData.orderId !== null);
            (tests["Type is Not Null"] = jsonData.type !== null);
            (tests["Title is Not Null"] = jsonData.title !== null);
            (tests["Description is Not Null"] = jsonData.description !== null);
            (tests["Image is Not Null"] = jsonData.image !== null);
            (tests["Sell Price is Not Null"] = jsonData.sellPrice !== null);
            (tests["Amount is Not Null"] = jsonData.amount !== null);
            (tests["Issued Status is Not Null"] = jsonData.issuedStatus !== null);
            (tests["Created At is Not Null"] = jsonData.createdAt !== null);
            (tests["Updated At is Not Null"] = jsonData.updatedAt !== null);
        
        (tests["Payment is Not Null"] = jsonData.payment !== null);
        (tests["Payment ID is Not Null"] = jsonData.paymentId !== null);
        (tests["Sell Price is Not Null"] = jsonData.sellPrice !== null);
        (tests["Status is Not Null"] = jsonData.status !== null);
        
        // Set Environment
        postman.setEnvironmentVariable("Order ID MO", jsonData.orderId);
        postman.setEnvironmentVariable("Title MO", jsonData.title);
        postman.setEnvironmentVariable("Description MO", jsonData.description);
        postman.setEnvironmentVariable("User ID MO", jsonData.userId);
        postman.setEnvironmentVariable("Status MO", jsonData.status);
        postman.setEnvironmentVariable("Main Type MO", jsonData.mainType);
        postman.setEnvironmentVariable("Product Type MO", jsonData.productType);
        postman.setEnvironmentVariable("Expired at MO", jsonData.expiredAt);
        postman.setEnvironmentVariable("Create at MO", jsonData.createdAt);
        
        postman.setEnvironmentVariable("Note MO", jsonData.note);
        
        // Set Next Request
}